# History - v0.1.0

* [**Table of Contents**](toc.md)
* **History**

## History

# Version History

This page summarizes published versions of the IG. The authoritative list is derived from **`package-list.json`** at the project root.

* **CI Build:** current development build (may include unpublished changes).
* **Release tags** (e.g., 0.1.0): published snapshots with immutable content.

If you maintain multiple published versions, the template’s version switcher will appear in the header when `package-list.json` includes them.

